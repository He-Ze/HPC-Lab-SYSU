#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <vector>
#include <string.h>

void gemm(double* matA,double* matB,double* matC,const int M,const int N,const int K);
void matrix_multiply(double* matA, double* matB, double* matC, const int M, const int N, const int K);

